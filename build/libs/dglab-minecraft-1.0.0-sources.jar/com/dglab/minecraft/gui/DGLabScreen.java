package com.dglab.minecraft.gui;

import com.dglab.minecraft.*;
import java.awt.image.BufferedImage;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class DGLabScreen extends class_437 {
    private static final int QR_SIZE = 150;
    private static final int PANEL_WIDTH = 200;
    private static final int PADDING = 10;
    private static final int QR_UPDATE_INTERVAL = 10;
    
    private BufferedImage qrImage;
    private int tickCounter = 0;
    private boolean needsQRUpdate = true;
    private class_357 baseStrengthSlider;
    private class_357 maxStrengthSlider;
    private class_4185 modeButton;
    private class_4185 serverButton;
    private class_4185 networkButton;
    
    public DGLabScreen() {
        super(class_2561.method_43471("gui.dglab.title"));
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int leftPanelX = PADDING + 10;
        int startY = 45;
        
        modeButton = class_4185.method_46430(
            DGLabConfig.useLocalServer 
                ? class_2561.method_43471("gui.dglab.mode_local")
                : class_2561.method_43471("gui.dglab.mode_remote"),
            button -> {
                DGLabConfig.useLocalServer = !DGLabConfig.useLocalServer;
                button.method_25355(DGLabConfig.useLocalServer 
                    ? class_2561.method_43471("gui.dglab.mode_local")
                    : class_2561.method_43471("gui.dglab.mode_remote"));
                requestQRUpdate();
            }
        ).method_46434(leftPanelX, startY, PANEL_WIDTH, 20).method_46431();
        this.method_37063(modeButton);
        
        if (DGLabConfig.useLocalServer) {
            initLocalServerMode(leftPanelX, startY + 25);
        } else {
            initRemoteServerMode(leftPanelX, startY + 25);
        }
        
        updateQRCode();
    }
    
    private void initLocalServerMode(int x, int startY) {
        serverButton = class_4185.method_46430(
            DGLabMinecraft.localServer.isRunning()
                ? class_2561.method_43471("gui.dglab.server_stop")
                : class_2561.method_43471("gui.dglab.server_start"),
            button -> {
                if (DGLabMinecraft.localServer.isRunning()) {
                    DGLabMinecraft.stopLocalServer();
                    button.method_25355(class_2561.method_43471("gui.dglab.server_start"));
                } else {
                    DGLabMinecraft.startLocalServer();
                    button.method_25355(class_2561.method_43471("gui.dglab.server_stop"));
                }
                requestQRUpdate();
            }
        ).method_46434(x, startY, PANEL_WIDTH, 20).method_46431();
        this.method_37063(serverButton);
        
        String currentNetwork = DGLabMinecraft.networkAdapter.getCurrentNetworkName();
        String currentIp = DGLabMinecraft.networkAdapter.getCurrentIpAddress();
        networkButton = class_4185.method_46430(
            class_2561.method_43470(currentNetwork + ": " + currentIp),
            button -> {
                String nextIp = DGLabMinecraft.networkAdapter.getNextIpAddress();
                String nextName = DGLabMinecraft.networkAdapter.getCurrentNetworkName();
                button.method_25355(class_2561.method_43470(nextName + ": " + nextIp));
                DGLabConfig.currentNetworkName = nextName;
                requestQRUpdate();
            }
        ).method_46434(x, startY + 25, PANEL_WIDTH, 20).method_46431();
        this.method_37063(networkButton);
        
        addSettingsWidgets(x, startY + 55);
    }
    
    private void initRemoteServerMode(int x, int startY) {
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.dglab.connect"), button -> {
            DGLabMinecraft.wsClient.connect(DGLabConfig.DEFAULT_SERVER);
            requestQRUpdate();
        }).method_46434(x, startY, 95, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.dglab.disconnect"), button -> {
            DGLabMinecraft.wsClient.disconnect();
            requestQRUpdate();
        }).method_46434(x + 105, startY, 95, 20).method_46431());
        
        addSettingsWidgets(x, startY + 30);
    }
    
    private void addSettingsWidgets(int x, int startY) {
        this.method_37063(class_4185.method_46430(
            class_2561.method_43471("gui.dglab.channel").method_27661().method_27693(": " + DGLabConfig.channel.get()), 
            button -> {
                DGLabConfig.channel.set(DGLabConfig.channel.get() == 1 ? 2 : 1);
                button.method_25355(class_2561.method_43471("gui.dglab.channel").method_27661().method_27693(": " + DGLabConfig.channel.get()));
            }
        ).method_46434(x, startY, PANEL_WIDTH, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(
            DGLabConfig.enabled.get() 
                ? class_2561.method_43471("gui.dglab.enabled").method_27661().method_27693(": ON")
                : class_2561.method_43471("gui.dglab.enabled").method_27661().method_27693(": OFF"),
            button -> {
                DGLabConfig.enabled.set(!DGLabConfig.enabled.get());
                button.method_25355(DGLabConfig.enabled.get() 
                    ? class_2561.method_43471("gui.dglab.enabled").method_27661().method_27693(": ON")
                    : class_2561.method_43471("gui.dglab.enabled").method_27661().method_27693(": OFF"));
            }
        ).method_46434(x, startY + 25, PANEL_WIDTH, 20).method_46431());
        
        baseStrengthSlider = new class_357(x, startY + 50, PANEL_WIDTH, 20, 
            class_2561.method_43471("gui.dglab.base_strength").method_27661().method_27693(": " + DGLabConfig.baseStrength), 
            DGLabConfig.baseStrength / 100.0) {
            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43471("gui.dglab.base_strength").method_27661().method_27693(": " + (int)(this.field_22753 * 100)));
            }
            
            @Override
            protected void method_25344() {
                DGLabConfig.baseStrength = (int)(this.field_22753 * 100);
            }
        };
        this.method_37063(baseStrengthSlider);
        
        maxStrengthSlider = new class_357(x, startY + 75, PANEL_WIDTH, 20, 
            class_2561.method_43471("gui.dglab.max_strength").method_27661().method_27693(": " + DGLabConfig.maxStrength), 
            DGLabConfig.maxStrength / 100.0) {
            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43471("gui.dglab.max_strength").method_27661().method_27693(": " + (int)(this.field_22753 * 100)));
            }
            
            @Override
            protected void method_25344() {
                DGLabConfig.maxStrength = (int)(this.field_22753 * 100);
            }
        };
        this.method_37063(maxStrengthSlider);
        
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.dglab.test_pulse"), button -> {
            if (DGLabConfig.useLocalServer && DGLabMinecraft.localServer.isBound()) {
                DGLabMinecraft.localServer.clearPulseQueue(DGLabConfig.channel.get());
                DGLabMinecraft.localServer.sendPulse(DGLabConfig.channel.get(), 
                    PulseGenerator.generatePulse(DGLabConfig.channel.get(), DGLabConfig.baseStrength, 50, 300));
            } else if (!DGLabConfig.useLocalServer && DGLabMinecraft.wsClient.isBound()) {
                DGLabMinecraft.wsClient.clearPulseQueue(DGLabConfig.channel.get());
                DGLabMinecraft.wsClient.sendPulse(DGLabConfig.channel.get(), DGLabConfig.baseStrength, 50, 300);
            }
        }).method_46434(x, startY + 100, PANEL_WIDTH, 20).method_46431());
    }
    
    private void updateQRCode() {
        qrImage = null;
        
        if (DGLabConfig.useLocalServer) {
            if (DGLabMinecraft.localServer.isRunning()) {
                String ipAddress = DGLabMinecraft.networkAdapter.getCurrentIpAddress();
                String qrContent = DGLabMinecraft.localServer.getQrContent(ipAddress);
                qrImage = QRCodeGenerator.generateQRCode(qrContent, QR_SIZE, QR_SIZE);
            }
        } else {
            String clientId = DGLabMinecraft.wsClient.getClientId();
            if (clientId != null && DGLabMinecraft.wsClient.isConnected()) {
                String qrContent = "https://www.dungeon-lab.com/app-download.php#DGLAB-SOCKET#wss://ws.dungeon-lab.cn/" + clientId;
                qrImage = QRCodeGenerator.generateQRCode(qrContent, QR_SIZE, QR_SIZE);
            }
        }
    }
    
    @Override
    public void method_25393() {
        super.method_25393();
        tickCounter++;
        if (needsQRUpdate && tickCounter >= QR_UPDATE_INTERVAL) {
            updateQRCode();
            tickCounter = 0;
            needsQRUpdate = false;
        }
    }
    
    public void requestQRUpdate() {
        needsQRUpdate = true;
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        
        class_2561 status;
        int statusColor;
        
        if (DGLabConfig.useLocalServer) {
            if (DGLabMinecraft.localServer.isBound()) {
                status = class_2561.method_43471("gui.dglab.status.connected_bound");
                statusColor = 0x55FF55;
            } else if (DGLabMinecraft.localServer.isRunning()) {
                status = class_2561.method_43471("gui.dglab.status.waiting");
                statusColor = 0xFFFF55;
            } else {
                status = class_2561.method_43471("gui.dglab.status.server_stopped");
                statusColor = 0xFF5555;
            }
        } else {
            if (DGLabMinecraft.wsClient.isBound()) {
                status = class_2561.method_43471("gui.dglab.status.connected_bound");
                statusColor = 0x55FF55;
            } else if (DGLabMinecraft.wsClient.isConnected()) {
                status = class_2561.method_43471("gui.dglab.status.connected");
                statusColor = 0xFFFF55;
            } else {
                status = class_2561.method_43471("gui.dglab.status.disconnected");
                statusColor = 0xFF5555;
            }
        }
        
        int leftPanelX = PADDING + 10;
        context.method_27535(this.field_22793, class_2561.method_43471("gui.dglab.title"), leftPanelX, 15, 0xFFFFFF);
        context.method_27535(this.field_22793, status, leftPanelX, 30, statusColor);
        
        int qrAreaX = this.field_22789 - QR_SIZE - PADDING * 3;
        int qrAreaY = PADDING + 20;
        int qrAreaWidth = QR_SIZE + PADDING * 4;
        int qrAreaHeight = QR_SIZE + PADDING * 4 + 30;
        
        context.method_25294(qrAreaX - PADDING, qrAreaY - PADDING, 
            qrAreaX + QR_SIZE + PADDING * 3, qrAreaY + QR_SIZE + PADDING * 3 + 20, 
            0x80000000);
        
        context.method_27534(this.field_22793, class_2561.method_43471("gui.dglab.qr_title"), 
            qrAreaX + QR_SIZE / 2 + PADDING, qrAreaY, 0xFFFFFF);
        
        int qrY = qrAreaY + 15;
        
        if (qrImage != null) {
            int qrX = qrAreaX + PADDING;
            
            context.method_25294(qrX - 5, qrY - 5, qrX + QR_SIZE + 5, qrY + QR_SIZE + 5, 0xFFFFFFFF);
            renderQRImage(context, qrX, qrY);
            
            context.method_27534(this.field_22793, 
                class_2561.method_43471("gui.dglab.scan_qr"), 
                qrAreaX + QR_SIZE / 2 + PADDING, qrY + QR_SIZE + 10, 0xAAAAAA);
        } else {
            String messageKey = DGLabConfig.useLocalServer ? "gui.dglab.start_server_for_qr" : "gui.dglab.connect_for_qr";
            context.method_27534(this.field_22793, 
                class_2561.method_43471(messageKey), 
                qrAreaX + QR_SIZE / 2 + PADDING, qrY + QR_SIZE / 2, 0xAAAAAA);
        }
        
        if (DGLabConfig.useLocalServer && DGLabMinecraft.localServer.isRunning()) {
            String ip = DGLabMinecraft.networkAdapter.getCurrentIpAddress();
            int port = DGLabMinecraft.localServer.getPort();
            context.method_27534(this.field_22793, 
                class_2561.method_43470("ws://" + ip + ":" + port), 
                qrAreaX + QR_SIZE / 2 + PADDING, qrY + QR_SIZE + 25, 0x888888);
        }
    }
    
    private void renderQRImage(class_332 context, int x, int y) {
        if (qrImage == null) return;
        
        int width = qrImage.getWidth();
        int height = qrImage.getHeight();
        
        for (int py = 0; py < height; py++) {
            for (int px = 0; px < width; px++) {
                int rgb = qrImage.getRGB(px, py);
                boolean isBlack = (rgb & 0x00FFFFFF) == 0;
                if (isBlack) {
                    context.method_25294(x + px, y + py, x + px + 1, y + py + 1, 0xFF000000);
                }
            }
        }
    }
    
    @Override
    public boolean method_25422() {
        return true;
    }
}
