package com.dglab.minecraft.mixin;

import com.dglab.minecraft.DamageType;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import com.dglab.minecraft.DGLabMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public class PlayerEntityMixin {
    
    @Inject(method = "damage", at = @At("RETURN"))
    private void onDamage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ() && amount > 0) {
            class_1657 player = (class_1657)(Object)this;
            
            if (player.method_37908().field_9236) {
                String damageSourceName = source.method_5525();
                DamageType damageType = DamageType.fromDamageSource(damageSourceName);
                
                DGLabMinecraft.LOGGER.debug("Player took {} damage from {} (type: {})", 
                    amount, damageSourceName, damageType.name());
                
                DGLabMinecraft.setLastDamage(amount, damageType);
            }
        }
    }
}
