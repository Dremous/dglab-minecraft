package com.dglab.minecraft;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_2561;
import net.minecraft.class_7157;
import net.minecraft.class_746;

public class DGLabCommands {
    
    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register(DGLabCommands::registerCommands);
    }
    
    private static void registerCommands(CommandDispatcher<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> dispatcher, class_7157 registryAccess) {
        dispatcher.register(ClientCommandManager.literal("dglab")
            .then(ClientCommandManager.literal("connect")
                .executes(DGLabCommands::connect)
                .then(ClientCommandManager.argument("server", com.mojang.brigadier.arguments.StringArgumentType.string())
                    .executes(DGLabCommands::connectWithServer)))
            .then(ClientCommandManager.literal("disconnect")
                .executes(DGLabCommands::disconnect))
            .then(ClientCommandManager.literal("bind")
                .then(ClientCommandManager.argument("targetId", com.mojang.brigadier.arguments.StringArgumentType.string())
                    .executes(DGLabCommands::bind)))
            .then(ClientCommandManager.literal("enable")
                .executes(DGLabCommands::enable))
            .then(ClientCommandManager.literal("disable")
                .executes(DGLabCommands::disable))
            .then(ClientCommandManager.literal("channel")
                .then(ClientCommandManager.argument("channel", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 2))
                    .executes(DGLabCommands::setChannel)))
            .then(ClientCommandManager.literal("strength")
                .then(ClientCommandManager.argument("base", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 100))
                    .then(ClientCommandManager.argument("max", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 100))
                        .executes(DGLabCommands::setStrength))))
            .then(ClientCommandManager.literal("test")
                .then(ClientCommandManager.argument("strength", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 100))
                    .executes(DGLabCommands::testPulse)))
            .then(ClientCommandManager.literal("status")
                .executes(DGLabCommands::status))
            .then(ClientCommandManager.literal("qr")
                .executes(DGLabCommands::showQR))
        );
    }
    
    private static int connect(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        DGLabMinecraft.wsClient.connect(DGLabConfig.DEFAULT_SERVER);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Connecting to DG-LAB server..."), false);
        return 1;
    }
    
    private static int connectWithServer(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        String server = com.mojang.brigadier.arguments.StringArgumentType.getString(context, "server");
        DGLabMinecraft.wsClient.connect(server);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Connecting to " + server + "..."), false);
        return 1;
    }
    
    private static int disconnect(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        DGLabMinecraft.wsClient.disconnect();
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Disconnected from DG-LAB"), false);
        return 1;
    }
    
    private static int bind(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        String targetId = com.mojang.brigadier.arguments.StringArgumentType.getString(context, "targetId");
        DGLabMinecraft.wsClient.bindToApp(targetId);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Binding to APP: " + targetId), false);
        return 1;
    }
    
    private static int enable(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        DGLabConfig.enabled.set(true);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("DG-LAB damage pulse enabled"), false);
        return 1;
    }
    
    private static int disable(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        DGLabConfig.enabled.set(false);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("DG-LAB damage pulse disabled"), false);
        return 1;
    }
    
    private static int setChannel(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        int channel = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "channel");
        DGLabConfig.channel.set(channel);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Channel set to " + channel), false);
        return 1;
    }
    
    private static int setStrength(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        int base = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "base");
        int max = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "max");
        DGLabConfig.baseStrength = base;
        DGLabConfig.maxStrength = max;
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Strength set: base=" + base + ", max=" + max), false);
        return 1;
    }
    
    private static int testPulse(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        int strength = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "strength");
        DGLabMinecraft.wsClient.clearPulseQueue(DGLabConfig.channel.get());
        DGLabMinecraft.wsClient.sendPulse(DGLabConfig.channel.get(), strength, 50, 300);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Test pulse sent: strength=" + strength), false);
        return 1;
    }
    
    private static int status(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        class_746 player = context.getSource().getPlayer();
        player.method_7353(class_2561.method_43470("=== DG-LAB Status ==="), false);
        player.method_7353(class_2561.method_43470("Connected: " + DGLabMinecraft.wsClient.isConnected()), false);
        player.method_7353(class_2561.method_43470("Bound: " + DGLabMinecraft.wsClient.isBound()), false);
        player.method_7353(class_2561.method_43470("Enabled: " + DGLabConfig.enabled.get()), false);
        player.method_7353(class_2561.method_43470("Channel: " + DGLabConfig.channel.get()), false);
        player.method_7353(class_2561.method_43470("Base Strength: " + DGLabConfig.baseStrength), false);
        player.method_7353(class_2561.method_43470("Max Strength: " + DGLabConfig.maxStrength), false);
        if (DGLabMinecraft.wsClient.getClientId() != null) {
            player.method_7353(class_2561.method_43470("Client ID: " + DGLabMinecraft.wsClient.getClientId()), false);
        }
        return 1;
    }
    
    private static int showQR(CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> context) {
        String clientId = DGLabMinecraft.wsClient.getClientId();
        if (clientId == null) {
            context.getSource().getPlayer().method_7353(class_2561.method_43470("Not connected. Use /dglab connect first."), false);
            return 0;
        }
        
        String qrContent = "https://www.dungeon-lab.com/app-download.php#DGLAB-SOCKET#wss://ws.dungeon-lab.cn/" + clientId;
        context.getSource().getPlayer().method_7353(class_2561.method_43470("QR Code content:"), false);
        context.getSource().getPlayer().method_7353(class_2561.method_43470(qrContent), false);
        context.getSource().getPlayer().method_7353(class_2561.method_43470("Scan this with DG-LAB APP to bind"), false);
        return 1;
    }
}
